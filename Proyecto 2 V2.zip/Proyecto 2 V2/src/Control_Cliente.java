import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Control_Cliente {
    private List<Cliente> clientes;
    private List<Compra> compras;

    public Control_Cliente() {
        clientes = new ArrayList<>();
        compras = new ArrayList<>();
    }

    /**
     * Agrega un nuevo cliente a la lista de clientes.
     *
     * @param controlGaleria El objeto Control_Galeria que contiene la lista de clientes.
     */
    public void agregarCliente(Control_Galeria controlGaleria) {
        // Obtener la lista de clientes de Control_Galeria
        List<Cliente> listaClientes = controlGaleria.getListaClientes();

        // Pedir cédula del cliente
        long cedula = obtenerCedula();

        // Verificar si el cliente ya existe
        if (existeCliente(listaClientes, cedula)) {
            System.out.println("El cliente ya existe en la lista.");
            return;
        }

        // Pedir los demás datos del cliente
        String nombre = obtenerNombre();
        String direccion = obtenerDireccion();
        String correoElectronico = obtenerCorreoElectronico();

        // Crear y agregar el nuevo cliente
        Cliente nuevoCliente = new Cliente(cedula, nombre, direccion, correoElectronico);
        listaClientes.add(nuevoCliente);

        System.out.println("Cliente registrado con éxito.");
    }

    /**
     * Elimina un cliente de la lista de clientes.
     *
     * @param controlGaleria El objeto Control_Galeria que contiene la lista de clientes.
     */
    public void eliminarCliente(Control_Galeria controlGaleria) {
        // Obtener la lista de clientes de Control_Galeria
        List<Cliente> listaClientes = controlGaleria.getListaClientes();

        // Pedir cédula del cliente a eliminar
        long cedula = obtenerCedula();

        // Buscar el cliente en la lista
        Cliente clienteAEliminar = null;
        for (Cliente cliente : listaClientes) {
            if (cliente.getCedula() == cedula) {
                clienteAEliminar = cliente;
                break;
            }
        }

        // Verificar si se encontró el cliente
        if (clienteAEliminar == null) {
            System.out.println("El cliente no fue encontrado.");
            return;
        }

        // Eliminar el cliente
        listaClientes.remove(clienteAEliminar);
        System.out.println("Cliente eliminado con éxito.");
    }

    /**
     * Lista todas las compras de un cliente.
     *
     * @param clientes La lista de clientes.
     * @param compras  La lista de compras.
     */
    public void listarComprasCliente(List<Cliente> clientes, List<Compra> compras) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Ingrese el número de cédula del cliente:");
        long cedulaCliente = scanner.nextLong();
        scanner.nextLine(); // Consumir la nueva línea después del nextLong()

        boolean clienteEncontrado = false;
        for (Cliente cliente : clientes) {
            if (cliente.getCedula() == cedulaCliente) {
                clienteEncontrado = true;

                System.out.println("Compras del cliente " + cliente.getNombre() + ":");

                boolean comprasClienteEncontradas = false;
                for (Compra compra : compras) {
                    if (compra.getCliente().getCedula() == cedulaCliente) {
                        System.out.println("Fecha de Compra: " + compra.getFechaCompra());
                        System.out.println("Obra: " + compra.getObra().getTitulo());
                        System.out.println("Precio: " + compra.getPrecio());
                        System.out.println("-----------------------");
                        comprasClienteEncontradas = true;
                    }
                }

                if (!comprasClienteEncontradas) {
                    System.out.println("El cliente no tiene compras registradas.");
                }

                break;
            }
        }

        if (!clienteEncontrado) {
            System.out.println("El cliente no fue encontrado.");
        }
    }

    // Métodos auxiliares para obtener los datos del cliente

    private long obtenerCedula() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Ingrese el número de cédula del cliente:");
        return scanner.nextLong();
    }

    private String obtenerNombre() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Ingrese el nombre del cliente:");
        return scanner.nextLine();
    }

    private String obtenerDireccion() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Ingrese la dirección del cliente:");
        return scanner.nextLine();
    }

    private String obtenerCorreoElectronico() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Ingrese el correo electrónico del cliente:");
        return scanner.nextLine();
    }

    // Método auxiliar para verificar si un cliente ya existe en la lista

    private boolean existeCliente(List<Cliente> listaClientes, long cedula) {
        for (Cliente cliente : listaClientes) {
            if (cliente.getCedula() == cedula) {
                return true;
            }
        }
        return false;
    }
}
