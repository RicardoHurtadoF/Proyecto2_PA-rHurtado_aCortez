import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import java.text.SimpleDateFormat;
import java.text.ParseException;

public class Control_Galeria {
    private List<Artista> artistas;
    private List<Obra> obras;
    private List<Compra> compras;
    private List<Cliente> clientes;

    public Control_Galeria() {
        artistas = new ArrayList<>();
        obras = new ArrayList<>();
        compras = new ArrayList<>();
        clientes = new ArrayList<>();
    }

    public List<Cliente> getListaClientes() {
        return clientes;
    }

    public List<Artista> getArtistas() {
        return artistas;
    }

    public List<Obra> getObras() {
        return obras;
    }

    public void agregarArtista() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Ingrese el nombre del artista:");
        String nombre = scanner.nextLine();

        boolean existeArtista = false;
        for (Artista artista : artistas) {
            if (artista.getNombre().equalsIgnoreCase(nombre)) {
                existeArtista = true;
                break;
            }
        }

        if (!existeArtista) {
            System.out.println("Ingrese la nacionalidad del artista:");
            String nacionalidad = scanner.nextLine();

            System.out.println("Ingrese la fecha de nacimiento del artista (dd/mm/aaaa):");
            String fechaNacimientoStr = scanner.nextLine();

            Date fechaNacimiento = null;
            try {
                SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
                fechaNacimiento = dateFormat.parse(fechaNacimientoStr);
            } catch (ParseException e) {
                System.out.println("Error al analizar la fecha de nacimiento. El artista no será agregado.");
                return;
            }

            System.out.println("Ingrese la biografía del artista:");
            String biografia = scanner.nextLine();

            Artista nuevoArtista = new Artista(nombre, nacionalidad, fechaNacimiento, biografia);
            artistas.add(nuevoArtista);
            System.out.println("Artista agregado correctamente.");
        } else {
            System.out.println("El artista ya está registrado.");
        }
    }

    public void eliminarArtista() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Ingrese el nombre del artista a eliminar:");
        String nombre = scanner.nextLine();

        boolean encontrado = false;
        for (Artista artista : artistas) {
            if (artista.getNombre().equalsIgnoreCase(nombre)) {
                encontrado = true;
                artistas.remove(artista);
                System.out.println("Artista eliminado correctamente.");
                break;
            }
        }

        if (!encontrado) {
            System.out.println("El artista no fue encontrado.");
        }
    }

    public void listarObras() {
        System.out.println("Lista de Obras:");
        for (Obra obra : obras) {
            System.out.println("Título: " + obra.getTitulo());
            System.out.println("Técnica: " + obra.getTecnica());
            System.out.println("Fecha de Creación: " + obra.getFechaCreacion());
            System.out.println("Precio: " + obra.getPrecio());
            System.out.println("Artista: " + obra.getArtista().getNombre());
            System.out.println("-----------------------");
        }
    }

    public void listarArtistas() {
        System.out.println("Lista de Artistas:");
        for (Artista artista : artistas) {
            System.out.println("Nombre: " + artista.getNombre());
            System.out.println("Nacionalidad: " + artista.getNacionalidad());
            System.out.println("Fecha de Nacimiento: " + artista.getFechaNacimiento());
            System.out.println("Biografía: " + artista.getBiografia());
            System.out.println("-----------------------");
        }
    }

    public void listarClientes() {
        System.out.println("Lista de Clientes:");
        for (Cliente cliente : clientes) {
            System.out.println("Nombre: " + cliente.getNombre());
            System.out.println("Cédula: " + cliente.getCedula());
            System.out.println("Dirección: " + cliente.getDireccion());
            System.out.println("Correo Electrónico: " + cliente.getCorreoElectronico());
            System.out.println("-----------------------");
        }
    }

    public void realizarCompra() {
        Scanner scanner = new Scanner(System.in);

        // Paso 1: Pedir el número de cédula del cliente
        System.out.println("Ingrese el número de cédula del cliente:");
        long cedulaCliente = scanner.nextLong();
        scanner.nextLine(); // Consumir la nueva línea después del nextLong()

        // Verificar si el cliente existe en la lista de clientes
        boolean clienteEncontrado = false;
        Cliente cliente = null;
        for (Cliente clienteActual : clientes) {
            if (clienteActual.getCedula() == cedulaCliente) {
                clienteEncontrado = true;
                cliente = clienteActual;
                break;
            }
        }

        if (!clienteEncontrado) {
            System.out.println("El cliente no está registrado. Registre al cliente antes de realizar una compra.");
            return; // Detener la función
        }

        // Paso 2: Pedir el título de la obra
        System.out.println("Ingrese el título de la obra:");
        String tituloObra = scanner.nextLine();

        // Verificar si la obra existe en la lista de obras
        boolean obraEncontrada = false;
        Obra obra = null;
        for (Obra obraActual : obras) {
            if (obraActual.getTitulo().equalsIgnoreCase(tituloObra)) {
                obraEncontrada = true;
                obra = obraActual;
                break;
            }
        }

        if (!obraEncontrada) {
            System.out.println("La obra no está disponible en la galería.");
            return; // Detener la función
        }

        // Paso 3: Tomar los datos del cliente y la obra encontrados y registrar una nueva compra
        System.out.println("Ingrese la fecha de compra (dd/mm/aaaa):");
        String fechaCompraStr = scanner.nextLine();

        Date fechaCompra = null;
        try {
            SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
            fechaCompra = dateFormat.parse(fechaCompraStr);
        } catch (ParseException e) {
            System.out.println("Error al analizar la fecha de compra. La compra no será registrada.");
            return;
        }

        double precioCompra = obra.getPrecio();
        Compra compra = new Compra(fechaCompra, cliente, obra, precioCompra);
        compras.add(compra);

        // Eliminar la obra de la lista de obras
        obras.remove(obra);

        System.out.println("Compra registrada correctamente. La obra ha sido eliminada de la lista de obras.");
    }

    public void listarCompras() {
        System.out.println("Lista de Compras:");
        for (Compra compra : compras) {
            System.out.println("Fecha de Compra: " + compra.getFechaCompra());
            System.out.println("Cliente: " + compra.getCliente().getNombre());
            System.out.println("Obra: " + compra.getObra().getTitulo());
            System.out.println("Precio: " + compra.getPrecio());
            System.out.println("-----------------------");
        }
    }

    public void listarComprasCliente() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Ingrese el número de cédula del cliente:");
        long cedulaCliente = scanner.nextLong();
        scanner.nextLine(); // Consumir la nueva línea después del nextLong()

        // Buscar el cliente por su cédula
        Cliente cliente = null;
        for (Cliente c : clientes) {
            if (c.getCedula() == cedulaCliente) {
                cliente = c;
                break;
            }
        }

        if (cliente != null) {
            System.out.println("Lista de Compras del Cliente " + cliente.getNombre() + ":");
            boolean comprasEncontradas = false;
            for (Compra compra : compras) {
                if (compra.getCliente() == cliente) {
                    System.out.println("Fecha de Compra: " + compra.getFechaCompra());
                    System.out.println("Obra: " + compra.getObra().getTitulo());
                    System.out.println("Precio: " + compra.getPrecio());
                    System.out.println("-----------------------");
                    comprasEncontradas = true;
                }
            }
            if (!comprasEncontradas) {
                System.out.println("El cliente no ha realizado compras.");
            }
        } else {
            System.out.println("El cliente no fue encontrado.");
        }
    }
    public void listarObrasPorArtista(String nombreArtista) {
        System.out.println("Obras del artista " + nombreArtista + ":");
        for (Obra obra : obras) {
            if (obra.getArtista().getNombre().equals(nombreArtista)) {
                System.out.println("Título: " + obra.getTitulo());
                System.out.println("Técnica: " + obra.getTecnica());
                System.out.println("Fecha de Creación: " + obra.getFechaCreacion());
                System.out.println("Precio: " + obra.getPrecio());
                System.out.println("-----------------------");
            }
        }
    }
}
