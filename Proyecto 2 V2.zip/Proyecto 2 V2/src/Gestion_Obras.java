import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

public class Gestion_Obras {
    private List<Obra> obras;
    private List<Artista> artistas;

    public Gestion_Obras(List<Artista> artistas, List<Obra> obras) {
        this.artistas = artistas;
        this.obras=obras;
    }

    public void agregarObra() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Ingrese el título de la obra:");
        String titulo = scanner.nextLine();

        boolean existeObra = false;
        for (Obra obra : obras) {
            if (obra.getTitulo().equalsIgnoreCase(titulo)) {
                existeObra = true;
                break;
            }
        }

        if (!existeObra) {
            System.out.println("Ingrese la técnica de la obra:");
            String tecnica = scanner.nextLine();

            System.out.println("Ingrese la fecha de creación de la obra (dd/mm/aaaa):");
            String fechaCreacionStr = scanner.nextLine();

            Date fechaCreacion = null;
            try {
                SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
                fechaCreacion = dateFormat.parse(fechaCreacionStr);
            } catch (ParseException e) {
                System.out.println("Error al analizar la fecha de creación. La obra no será agregada.");
                return;
            }

            System.out.println("Ingrese el precio de la obra:");
            double precio = scanner.nextDouble();
            scanner.nextLine(); // Consumir la nueva línea después del nextDouble()

            System.out.println("Ingrese el nombre del artista de la obra:");
            String nombreArtista = scanner.nextLine();

            boolean artistaEncontrado = false;
            for (Artista artista : artistas) {
                if (artista.getNombre().equalsIgnoreCase(nombreArtista)) {
                    artistaEncontrado = true;
                    Obra nuevaObra = new Obra(titulo, tecnica, fechaCreacion, precio, artista);
                    obras.add(nuevaObra);
                    System.out.println("Obra agregada correctamente.");
                    break;
                }
            }

            if (!artistaEncontrado) {
                System.out.println("El artista no fue encontrado, registre el artista antes de registrar la obra.");
            }
        } else {
            System.out.println("La obra ya está registrada.");
        }
    }

    public void eliminarObra() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Ingrese el título de la obra a eliminar:");
        String titulo = scanner.nextLine();

        boolean obraEncontrada = false;
        for (Obra obra : obras) {
            if (obra.getTitulo().equalsIgnoreCase(titulo)) {
                obras.remove(obra);
                obraEncontrada = true;
                System.out.println("Obra eliminada correctamente.");
                break;
            }
        }

        if (!obraEncontrada) {
            System.out.println("La obra no fue encontrada.");
        }
    }

}
