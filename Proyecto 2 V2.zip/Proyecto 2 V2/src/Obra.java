import java.util.Date;

public class Obra {
    private String titulo;
    private String tecnica;
    private Date fechaCreacion;
    private double precio;
    private Artista artista;

    public Obra(String titulo, String tecnica, Date fechaCreacion, double precio, Artista artista) {
        this.titulo = titulo;
        this.tecnica = tecnica;
        this.fechaCreacion = fechaCreacion;
        this.precio = precio;
        this.artista = artista;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getTecnica() {
        return tecnica;
    }

    public void setTecnica(String tecnica) {
        this.tecnica = tecnica;
    }

    public Date getFechaCreacion() {
        return fechaCreacion;
    }

    public void setFechaCreacion(Date fechaCreacion) {
        this.fechaCreacion = fechaCreacion;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public Artista getArtista() {
        return artista;
    }

    public void setArtista(Artista artista) {
        this.artista = artista;
    }
}

