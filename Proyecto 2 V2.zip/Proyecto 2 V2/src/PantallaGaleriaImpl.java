import java.util.List;

public class PantallaGaleriaImpl implements Pantalla_Galeria {
    private Control_Galeria controlGaleria;

    public PantallaGaleriaImpl(Control_Galeria controlGaleria) {
        this.controlGaleria = controlGaleria;
    }

    @Override
    public void mostrarObras(List<Obra> obras) {
        controlGaleria.listarObras();
    }

    @Override
    public void mostrarArtistas(List<Artista> artistas) {
        controlGaleria.listarArtistas();
    }

    @Override
    public void mostrarClientes(List<Cliente> clientes) {
        controlGaleria.listarClientes();
    }

    @Override
    public void mostrarCompras(List<Compra> compras) {
        controlGaleria.listarCompras();
    }
}
