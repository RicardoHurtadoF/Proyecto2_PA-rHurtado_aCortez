import java.util.List;

public interface Pantalla_Galeria {
    void mostrarObras(List<Obra> obras);
    void mostrarArtistas(List<Artista> artistas);
    void mostrarClientes(List<Cliente> clientes);
    void mostrarCompras(List<Compra> compras);
}

