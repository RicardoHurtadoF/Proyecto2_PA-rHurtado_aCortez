import java.util.List;

public class Cliente {
    private String nombre;
    private String direccion;
    private String correoElectronico;
    private long cedula;

    private List<Compra> compras;


    public Cliente(long cedula, String nombre,  String direccion, String correoElectronico) {
        this.cedula=cedula;
        this.nombre = nombre;
        this.direccion = direccion;
        this.correoElectronico = correoElectronico;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getCorreoElectronico() {
        return correoElectronico;
    }

    public void setCorreoElectronico(String correoElectronico) {
        this.correoElectronico = correoElectronico;
    }

    public long getCedula(){
        return cedula;
    }

    public void setCedula(long cedula){
        this.cedula=cedula;
    }

}
