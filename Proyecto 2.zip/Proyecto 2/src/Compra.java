import java.util.Date;

public class Compra {
    private Date fechaCompra;
    private Cliente cliente;
    private Obra obra;
    private double precio;

    public Compra(Date fechaCompra, Cliente cliente, Obra obra, double precio) {
        this.fechaCompra = fechaCompra;
        this.cliente = cliente;
        this.obra = obra;
        this.precio = precio;
    }

    public Date getFechaCompra() {
        return fechaCompra;
    }

    public void setFechaCompra(Date fechaCompra) {
        this.fechaCompra = fechaCompra;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public Obra getObra() {
        return obra;
    }

    public void setObra(Obra obra) {
        this.obra = obra;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }
}

