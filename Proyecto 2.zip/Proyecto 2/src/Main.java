import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.text.ParseException;
import java.util.*;

public class Main {
    public static void main(String[] args) {

        Control_Cliente controlCliente = new Control_Cliente();

        // Crear una instancia de Control_Galeria
        Control_Galeria controlGaleria = new Control_Galeria();

        Gestion_Obras gestionObras = new Gestion_Obras(controlGaleria.getArtistas(),controlGaleria.getObras());

        // Crear una instancia de PantallaGaleriaImpl
        Pantalla_Galeria pantallaGaleria = new PantallaGaleriaImpl(controlGaleria);

        // Crear las listas de artistas, obras, compras y clientes
        List<Artista> artistas = new ArrayList<>();
        List<Obra> obras = new ArrayList<>();
        List<Compra> compras = new ArrayList<>();
        List<Cliente> clientes = new ArrayList<>();

        // Crear artistas
        Artista artista1 = new Artista("Leonardo da Vinci", "Italiano", parseDate("15/04/1452"), "Leonardo da Vinci fue un polímata italiano del Renacimiento conocido principalmente por sus pinturas.");
        Artista artista2 = new Artista("Pablo Picasso", "Español", parseDate("25/10/1881"), "Pablo Picasso fue un pintor, escultor y ceramista español, considerado uno de los artistas más importantes del siglo XX.");
        Artista artista3 = new Artista("Frida Kahlo", "Mexicana", parseDate("06/07/1907"), "Frida Kahlo fue una pintora mexicana reconocida por su estilo único y su representación de la identidad y el sufrimiento personal.");

        // Agregar artistas a la lista de artistas
        artistas.add(artista1);
        artistas.add(artista2);
        artistas.add(artista3);

        // Crear obras
        Obra obra1 = new Obra("La última cena", "Óleo sobre tabla", parseDate("01/01/1495"), 12000000.0, artista1);
        Obra obra2 = new Obra("Guernica", "Óleo sobre lienzo", parseDate("01/01/1937"), 8000000.0, artista2);
        Obra obra3 = new Obra("Las dos Fridas", "Óleo sobre lienzo",parseDate("01/01/1939"), 5000000.0, artista3);

        // Agregar obras a la lista de obras
        obras.add(obra1);
        obras.add(obra2);
        obras.add(obra3);

        // Crear una instancia de Scanner para leer la entrada del usuario
        Scanner scanner = new Scanner(System.in);

        // Variable para almacenar la opción seleccionada por el usuario
        int opcion;

        // Menú interactivo
        do {
            System.out.println("1. Mostrar Obras");
            System.out.println("2. Mostrar Artistas");
            System.out.println("3. Mostrar Clientes");
            System.out.println("4. Mostrar Compras");
            System.out.println("5. Agregar Cliente");
            System.out.println("6. Eliminar Cliente");
            System.out.println("7. Agregar Artista");
            System.out.println("8. Eliminar Artista");
            System.out.println("9. Agregar Obra");
            System.out.println("10. Eliminar Obra");
            System.out.println("11. Listar Compras de Cliente");
            System.out.println("12. Realizar una compra");
            System.out.println("13. Listar obras por artista");
            System.out.println("0. Salir");
            System.out.print("Seleccione una opción: ");

            opcion = scanner.nextInt();

            switch (opcion) {
                case 1:
                    // Llamar al método mostrarObras de PantallaGaleriaImpl
                    pantallaGaleria.mostrarObras(obras);
                    break;
                case 2:
                    // Llamar al método mostrarArtistas de PantallaGaleriaImpl
                    pantallaGaleria.mostrarArtistas(artistas);
                    break;
                case 3:
                    // Llamar al método mostrarClientes de PantallaGaleriaImpl
                    pantallaGaleria.mostrarClientes(clientes);
                    break;
                case 4:
                    // Llamar al método mostrarCompras de PantallaGaleriaImpl
                    pantallaGaleria.mostrarCompras(compras);
                    break;
                case 5:
                    // Llamar al método agregarCliente de Control_Cliente
                    controlCliente.agregarCliente(controlGaleria);
                    break;
                case 6:
                    // Llamar al método eliminarCliente de Control_Cliente
                    controlCliente.eliminarCliente(controlGaleria);
                    break;
                case 7:
                    // Llamar al método
                    controlGaleria.agregarArtista();
                    break;
                case 8:
                    // Llamar al método
                    controlGaleria.eliminarArtista();
                    break;
                case 9:
                    // Llamar al método
                    gestionObras.agregarObra();
                    break;
                case 10:
                    // Llamar al método
                    gestionObras.eliminarObra();
                    break;
                case 11:
                    // Llamar al método listarComprasCliente de Control_Cliente
                    controlCliente.listarComprasCliente(clientes, compras);
                    break;
                case 12:
                    // Llamar al método realizarCompra de Control_Galeria
                    controlGaleria.realizarCompra();
                    break;
                case 13:
                    // Pedir el nombre del artista
                    System.out.print("Ingrese el nombre del artista: ");
                    String nombreArtista = scanner.nextLine();

                    // Llamar al método listarObrasPorArtista de Control_Galeria
                    gestionObras.listarObrasPorArtista(nombreArtista);
                    break;
                case 0:
                    System.out.println("Saliendo del programa...");
                    break;
                default:
                    System.out.println("Opción inválida. Por favor, seleccione una opción válida.");
                    break;
            }

            System.out.println();  // Imprimir una línea en blanco

        } while (opcion != 0);

        // Cerrar el scanner
        scanner.close();
    }
    // Función para convertir una cadena en un objeto Date
    public static Date parseDate(String dateStr) {
        SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
        try {
            return format.parse(dateStr);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return null;
    }
}
